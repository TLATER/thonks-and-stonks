# Mod balancing datapack

This datapack does the following:

- Removes elytras from end cities when they spawn in
- Makes all Tinker's Construct diamond-melting-down recipes take too
  much heat to be possible
  - TODO: In 1.19, it will become possible to just ignore existing
    recipes via the `filter` attribute in `pack.mcmeta`
    - This can then probably also be used to remove ship variants from
      end cities for more efficient end worldgen?
